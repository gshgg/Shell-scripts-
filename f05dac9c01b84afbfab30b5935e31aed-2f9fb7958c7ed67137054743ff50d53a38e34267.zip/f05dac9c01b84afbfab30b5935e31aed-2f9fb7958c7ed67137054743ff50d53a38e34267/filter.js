function filter(any, cb) {
    if (any === null) {
        return
    }
    const result = [];

    function pushStack(curr, stack) {
        let newStack;
        if (curr.length) {
            newStack = curr
        } else {
            const children = curr.children;
            if (!children || !children.length) {
                return;
            }
            newStack = children
        }
        Array.prototype.push.apply(stack, newStack);
    }

    function __(any) {
        let stack = [];
        if (cb(any) === true) {
            result.push(any)
        }
        pushStack(any, stack);
        while (stack.length) {
            const current = stack.shift();
            if (cb(current) === true) {
                result.push(current)
            }
            pushStack(current, stack);
        }
    }

    __(any);

    return result;
}