function find(any, cb) {
    if (any === null) {
        return
    }

    function pushStack(curr, stack) {
        let newStack;
        if (curr.length) {
            newStack = curr
        } else {
            const children = curr.children;
            if (!children || !children.length) {
                return;
            }
            newStack = children
        }
        Array.prototype.push.apply(stack, newStack);
    }

    function __(any) {
        let stack = [];
        if (cb(any) === true) {
            return any
        }
        pushStack(any, stack);
        while (stack.length) {
            const current = stack.shift();
            if (cb(current) === true) {
                return current
            }
            pushStack(current, stack);
        }
    }

    return __(any);
}