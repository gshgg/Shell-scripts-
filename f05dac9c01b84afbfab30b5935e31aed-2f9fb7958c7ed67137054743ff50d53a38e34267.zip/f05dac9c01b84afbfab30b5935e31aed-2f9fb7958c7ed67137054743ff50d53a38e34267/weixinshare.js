//[SDK](http://qydev.weixin.qq.com/wiki/index.php?title=%E5%BE%AE%E4%BF%A1JS-SDK%E6%8E%A5%E5%8F%A3)
window.shareWx = function (shareObj) {
    var wxScript = document.createElement('script');
    wxScript.src = '//res.wx.qq.com/open/js/jweixin-1.0.0.js';
    document
        .body
        .appendChild(wxScript);
    var get = function (opt) {
        var xmlHttp = new XMLHttpRequest();
        xmlHttp.open('GET', opt.url);
        xmlHttp.send(null);
        xmlHttp.onreadystatechange = function () {
            //console.log(xmlHttp)
            if (xmlHttp.readyState == 4) {
                var data = typeof xmlHttp.responseText === 'string'
                    ? JSON.parse(xmlHttp.responseText)
                    : xmlHttp.responseText;
                opt.success && opt.success(data);
            }
        }
    };
    wxScript.onload = function () {
        get({
            url: ''//查询appid之类的的接口,如果不用接口可以直接删掉get请求方法,使用success回调中的方法调用wx 接口也可以,
            success: function (data) {
                if (data.status == 200) {
                    data = data.data;
                    var configData = {
                        appId: data.appId, // 必填，公众号的唯一标识
                        timestamp: data.timestamp, // 必填，生成签名的时间戳
                        nonceStr: data.nonceStr, // 必填，生成签名的随机串
                        signature: data.signature, // 必填，签名，见附录1
                        jsApiList: ['onMenuShareAppMessage', 'onMenuShareTimeline'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
                    };

                    wx.config(configData);
                    wx.error(function (res) {
                        // alert(JSON.stringify(res))
                    })

                    wx.ready(function () {
                        shareObj.ready&&shareObj.ready()
                        wx.onMenuShareTimeline({
                            title: shareObj.title, // 分享标题
                            link: shareObj.link || window.location.href, // 分享链接
                            imgUrl: shareObj.imgUrl || 'http://xxxxx/share.png', // 分享图标
                            desc: shareObj.desc,
                            success: function () {
                                console.log([
                                    '内容',
                                    '分享',
                                    '分享到朋友圈成功',
                                    '',
                                    ''
                                ].join(','));
                            },
                            cancel: function () {
                                // 用户取消分享后执行的回调函数 alert('取消')
                            }
                        });
                        wx.onMenuShareAppMessage({
                            title: shareObj.title, // 分享标题
                            link: shareObj.link || window.location.href, // 分享链接
                            imgUrl: shareObj.imgUrl || 'http://xxxxx/share.png', // 分享图标
                            desc: shareObj.desc,
                            success: function () {
                                // 用户确认分享后执行的回调函数
                                console.log([
                                    '内容',
                                    '分享',
                                    '分享给朋友成功',
                                    '',
                                    ''
                                ].join(','));
                            },
                            cancel: function () {
                                // 用户取消分享后执行的回调函数
                            }
                        });
                    });
                }
            }
        })
    };
}


//run
shareWx({
    title: '****',
    desc: '****',
    ready: function () {
      
    }
})
